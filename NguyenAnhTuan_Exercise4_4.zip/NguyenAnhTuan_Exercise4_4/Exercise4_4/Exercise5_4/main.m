//
//  main.m
//  Exercise5_4
//
//  Created by Tuấn Nguyễn Anh on 5/15/13.
//  Copyright (c) 2013 Tuấn Nguyễn Anh. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TEAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TEAppDelegate class]));
    }
}
